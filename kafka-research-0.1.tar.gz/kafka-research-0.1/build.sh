#!/bin/sh

mvn clean install -Dmaven.compiler.showDeprecation=true -Dmaven.compiler.showWarnings=true
