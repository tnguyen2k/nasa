// package com.cloudurable.kafka.schema;
package poc;

// import com.cloudurable.phonebook.Employee;
// import com.cloudurable.phonebook.PhoneNumber;
// import io.confluent.kafka.serializers.KafkaAvroSerializerConfig;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.LongSerializer;
// import io.confluent.kafka.serializers.KafkaAvroSerializer;

import java.util.Properties;
import java.util.stream.IntStream;


/**
 * Class EmployeeProducer
 */
public class EmployeeProducer {
    private static Producer<Long, Employee> createProducer() {
        Properties props = new Properties();
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "EmployeeProducer");
        props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, EmployeeSerializer.class.getName());

        // Configure the KafkaAvroSerializer.
        /*
       props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                KafkaAvroSerializer.class.getName()); */
                /*
       props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG,
                         PayloadSerializer.class.getName()); */
        props.put("key.serializer", "org.apache.kafka.common.serialization.LongSerializer");
        props.put("value.serializer", EmployeeSerializer.class.getName());

        // Schema Registry location.
        props.put("schema.registry.url", // KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG,
                "http://localhost:8081");

        return new KafkaProducer<>(props);
    }

    public final static String TOPIC = "employee-test";


    /**
     * Main entry
     */
    public static void main(String... args) {
        Producer<Long, Employee> producer = createProducer();

        Employee bob = Employee.newBuilder().setAge(35)
                .setFirstName("Bob4")
                .setLastName("Jones4")
                .setPhoneNumber("800-200-0000")
                .build();

        /*
        IntStream.range(1, 100).forEach(index->{
            producer.send(new ProducerRecord<>(TOPIC, 1L * index, bob));

        });
        */

        ProducerRecord<Long, Employee> record = new ProducerRecord<>(TOPIC, 1L, bob);
        try {
            producer.send(record);
            System.out.println();
            System.out.println("Successfull send data for " + bob.getFirstName());
            System.out.println();
        }
        catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        finally {
            producer.flush();
            producer.close();
        }
    }

}

