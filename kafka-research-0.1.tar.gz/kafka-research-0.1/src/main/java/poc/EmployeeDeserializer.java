package poc;

import java.util.Map;
import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * Class EmployeeDeserializer
 */
public class EmployeeDeserializer implements org.apache.kafka.common.serialization.Deserializer<Employee> {
    @Override public void close() {
    }

    @Override public void configure(Map arg0, boolean arg1) {
    }

    @Override
    public Employee deserialize(String arg0, byte[] arg1) {
        ObjectMapper mapper = new ObjectMapper();
        Employee em = null;
        try {
            em = mapper.readValue(arg1, Employee.class);
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return em;
    }
}

