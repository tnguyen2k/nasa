package poc;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import org.apache.kafka.common.KafkaFuture;
import org.apache.kafka.common.errors.TopicExistsException;
import org.apache.kafka.clients.admin.AdminClient;
import org.apache.kafka.clients.admin.AdminClientConfig;
import org.apache.kafka.clients.admin.CreateTopicsResult;
import org.apache.kafka.clients.admin.ListTopicsResult;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.admin.TopicListing;
import org.apache.kafka.connect.data.Schema;
import org.apache.kafka.connect.data.SchemaBuilder;


/**
 * Class KafkaUtil
 * KafkaUtil for querying topics, deleting topics and creating topics
 * https://www.logicbig.com/tutorials/misc/kafka/admin-api-getting-started.html
 * https://kafka.apache.org/20/javadoc/org/apache/kafka/connect/data/SchemaBuilder.html
 * https://stackoverflow.com/questions/16946778/how-can-we-create-a-topic-in-kafka-from-the-ide-using-api
 * https://github.com/gschmutz/kafka-examples/blob/master/kafka-admin-client/src/test/java/com/trivadis/kafka/sample/TestKafkaAdminClient.java
 */
public class KafkaUtil {
    private static String DEFAULT_SERVER_INFO  =  "localhost:9092";

    public static void setDefaultServerInfo(final String serverInfo) {
        DEFAULT_SERVER_INFO = serverInfo;
    }

    public static AdminClient createAdminClient() {
        return createAdminClient(DEFAULT_SERVER_INFO);
    }

    public static AdminClient createAdminClient(String strServerInfo) {
        Properties config = new Properties();
        config.put(AdminClientConfig.BOOTSTRAP_SERVERS_CONFIG, strServerInfo);
        config.put(AdminClientConfig.REQUEST_TIMEOUT_MS_CONFIG, "5000");
        config.put(AdminClientConfig.RETRIES_CONFIG, 2);
        AdminClient admin = AdminClient.create(config);
        return admin;
    }

    public static boolean topicExists(String strTopic) throws Exception {
        return topicExists(null, strTopic);
    }

    public static boolean topicExists(AdminClient admin, String strTopic) throws Exception {
        boolean isClosed = false;
        try {
            if (admin == null) {
                admin = createAdminClient();
                isClosed = true;
            }

            boolean topicExists = admin.listTopics().names().get().stream().anyMatch(topicName -> topicName.equalsIgnoreCase(strTopic));
            return topicExists;
        }
        finally {
            if (isClosed) {
                admin.close();
            }
        }
    }

    public static List<String> listExternalTopics() throws Exception {
        return listExternalTopics(null);
    }

    public static List<String> listExternalTopics(AdminClient admin) throws Exception {
        boolean isClosed = false;
        if (admin == null) {
            admin = createAdminClient();
            isClosed = true;
        }

        try {
            List<String> topicList = new ArrayList<>();
            for (TopicListing topicListing : admin.listTopics().listings().get()) {
                if (!topicListing.isInternal()) {
                    topicList.add(topicListing.name());
                }
            }

            return topicList;
        }
        catch (Exception ex) {
            throw ex;
        }
        finally {
            if (isClosed) {
                admin.close();
            }
        }
    }

    public static List<String> listTopicsExcludeInternalTopics() throws Exception {
        return listTopics(null, false);
    }

    public static List<String> listAllTopics() throws Exception {
        return listTopics(null, false);
    }

    public static List<String> listTopics(AdminClient admin, boolean isAll) throws Exception {
        boolean isClosed = false;
        if (admin == null) {
            admin = createAdminClient();
            isClosed = true;
        }

        try {
            List<String> topicList = new ArrayList<>();
            ListTopicsResult ltr = admin.listTopics();
            KafkaFuture<Set<String>> names = ltr.names();
            Set<String> allTopics = names.get();
            for (String strTopic : allTopics) {
                if (isAll) {
                    topicList.add(strTopic);
                }
                else if (!strTopic.startsWith("_")) {
                    topicList.add(strTopic);
                }
            }

            return topicList;
        }
        catch (Exception ex) {
            throw ex;
        }
        finally {
            if (isClosed) {
                admin.close();
            }
        }
    }

    public static void createTopic(String strTopic, int partitionNum, int replicationNum) throws Exception {
        AdminClient admin = null;
        try {
            admin = createAdminClient();
            if (topicExists(admin, strTopic)) {
                System.out.println("Topic = " + strTopic + " exists");
                return;
            }

            Map<String, String> topicConfigs = new HashMap<>();
            final NewTopic newTopic = new NewTopic(strTopic, partitionNum, (short)replicationNum);
            newTopic.configs(topicConfigs);

            ArrayList<NewTopic> topicList = new ArrayList<>(8);
            topicList.add(newTopic);
            final CreateTopicsResult result = admin.createTopics(topicList);
            result.all().get();
            // KafkaFuture<Void> all = result.all();
            for (Map.Entry<String, KafkaFuture<Void>> entry : result.values().entrySet()) {
                try {
                    entry.getValue().get();
                    // log.info("topic {} created", entry.getKey());
                    // System.out.println("Created topic:  " + entry.getKey());
                }
                // catch (InterruptedException | ExecutionException e) {
                catch (Throwable e) {
                    if (e instanceof TopicExistsException) {
                        // log.info("topic {} existed", entry.getKey());
                        System.out.println("Existing topic: " + entry.getKey());
                    }
                }
            }
        }
        finally {
            if (admin != null) {
                admin.close();
            }
        }
    }

    public static boolean deleteTopic(String strTopic) throws Exception {
        return deleteTopic(null, strTopic);
    }

    public static boolean deleteTopic(AdminClient admin, String strTopic) throws Exception {
        boolean isClosed = false;
        if (admin == null) {
            admin = createAdminClient();
            isClosed = true;
        }

		    try {
            if (!topicExists(admin, strTopic)) {
                return false;
            }

            KafkaFuture<Void> future = admin.deleteTopics(Collections.singleton(strTopic)).all();
			      future.get();
            return true;
		    }
        catch (InterruptedException | ExecutionException e) {
			      // TODO Auto-generated catch block
			      // e.printStackTrace();
            throw e;
		    }
        finally {
            if (isClosed) {
                admin.close();
            }
        }
    }

    public static void printSchemaFromPOJO() {
        Schema schema = SchemaBuilder.struct()
          .name("sample.Employee").version(1)
          .field("firstName", Schema.STRING_SCHEMA)
          .field("lastName", Schema.STRING_SCHEMA)
          .field("age", Schema.INT16_SCHEMA)
          .field("phoneNumber", Schema.STRING_SCHEMA)
          .build();

        System.out.println();
        System.out.println(schema.toString());
        System.out.println();
    }

    public static void printUsage() {
        System.out.println();
        System.out.println("Usage: -create <topic> <partition-number> <replication-number>");
        System.out.println("Usage: -delete <topic>");
        System.out.println("Usage: -list");
        System.out.println("Usage: -printSchema");
        System.out.println();
    }

    /**
     * Main Entry
     */
    public static void main(String []args) {
        // org.apache.log4j.Logger.getLogger("org").setLevel(Level.WARN);
        // org.apache.log4j.Logger.getLogger("akka").setLevel(Level.WARN);
        // org.apache.log4j.Logger.getLogger("kafka").setLevel(Level.WARN);

        try {
            if (args.length == 1) {
                if (args[0].equals("-list")) {
                    List<String> topics = listExternalTopics();
                    System.out.println();
                    if (topics.isEmpty()) {
                        System.out.println("There are no kafka topics");
                    }
                    else {
                        System.out.println("Available kafka topic(s):");
                        for (String strTopic : topics) {
                            if (!strTopic.startsWith("_confluent")) {
                                System.out.println("  " + strTopic);
                            }
                        }
                    }
                }
                else if (args[0].equals("-printSchema")) {
                    printSchemaFromPOJO();
                    return;
                }
                else {
                    printUsage();
                    return;
                }
            }
            else if (args.length == 2) {
                if (!args[0].equals("-delete")) {
                    printUsage();
                    return;
                }

                boolean bRet = deleteTopic(args[1]);
                System.out.println();
                if (bRet) {
                    System.out.println("Successfully deleted topic = " + args[1]);
                }
                else {
                    System.out.println("Topic = " + args[1] + " does not exist");
                }
            }
            else if (args.length == 4) {
                if (!args[0].equals("-create")) {
                    printUsage();
                    return;
                }

                System.out.println("Creating topic = " + args[1]);
                createTopic(args[1], Integer.parseInt(args[2]), Integer.parseInt(args[3]));
                System.out.println();
                System.out.println("Successfully created topic = " + args[1]);
            }
            else {
                printUsage();
                return;
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}
