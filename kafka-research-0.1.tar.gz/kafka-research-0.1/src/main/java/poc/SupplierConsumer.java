package poc;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Arrays;
import java.util.Collections;
import java.util.Properties;


/**
 * Class SupplierConsumer
 */
public class SupplierConsumer {
    private static boolean IS_STOPPED  =  true;
    private static boolean IS_BEGINNING_OFFSET = true;

    private static Consumer<Long, Supplier> createConsumer() {
        final Properties props = new Properties();
         props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
         props.put(ConsumerConfig.GROUP_ID_CONFIG, "SupplyConsumerGroupId");
         props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, LongDeserializer.class.getName());
         // props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, PayloadDeserializer.class.getName());
         props.put("value.deserializer", SupplierDeserializer.class.getName());

         // Create the consumer using props.
         final Consumer<Long, Supplier> consumer = new KafkaConsumer<>(props);

         // Subscribe to the topic.
         consumer.subscribe(Collections.singletonList(SupplierProducer.TOPIC));
         return consumer;
    }

    private static void runConsumer() {
        final Consumer<Long, Supplier> consumer = createConsumer();
        final int giveUp = 1160;
        int noRecordsCount = 0;

        if (IS_BEGINNING_OFFSET) {
            /*
            int partitionId = 0;
            long offset = 0L;
            TopicPartition tpPartition = new TopicPartition(SupplierProducer.TOPIC, partitionId);
            consumer.assign(Arrays.asList(tpPartition));
            // consumer.seek​(tpPartition, offset);
            consumer.seekToBeginning(Arrays.asList(tpPartition));
            */

            consumer.seekToBeginning(consumer.assignment());
        }

        System.out.println("Running consumer ...");
        IS_STOPPED = false;
        try {
            while (!IS_STOPPED) {
                final ConsumerRecords<Long, Supplier> consumerRecords = consumer.poll(Duration.ofMillis(800));
                System.out.println("- Polling data ...");
                if (IS_STOPPED) {
                    break;
                }

                if (consumerRecords.count() == 0) {
                    noRecordsCount++;
                    if (noRecordsCount > giveUp)
                        break;
                    else
                        continue;
                }

                /*
                consumerRecords.forEach(record -> {
                    System.out.printf("Consumer Record:(%d, %s, %d, %d)\n",
                            record.key(), record.value(),
                            record.partition(), record.offset());
                });
                */

                for (ConsumerRecord<Long, Supplier> record : consumerRecords) {
                    System.out.printf("Received Consumer Record: (%d, %d, %d)\n", record.key(), record.partition(), record.offset());
                    Supplier value = record.value();
                    System.out.println("Name = " + value.getName() + ", date = " + value.getDate());
                }
                System.out.println();

                consumer.commitAsync();
            }
        }
        catch (Exception ex) {
            throw ex;
        }
        finally {
            consumer.close();
        }

        System.out.println("Supplier consumer exited");
    }


    /**
     * Main entry
     */
    public static void main(String... args) {
        try {
            Runtime.getRuntime().addShutdownHook(new Thread() {
                @Override
                public void run() {
                    System.out.println("Shutdown consumer ...");
                    IS_STOPPED = true;
                    try {
                        Thread.sleep(1400);
                    }
                    catch (Exception ex) {
                    }
                }
            });
            runConsumer();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

