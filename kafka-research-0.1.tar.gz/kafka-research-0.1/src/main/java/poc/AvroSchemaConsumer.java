package poc;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;
import org.apache.kafka.clients.consumer.*;
import gov.nasa.arc.freddie.EventType;
import gov.nasa.arc.freddie.Operation;
import gov.nasa.arc.freddie.OperationModel;
import gov.nasa.arc.freddie.State;


/**
 * Class AvroSchemaConsumer
 */
public class AvroSchemaConsumer {
    public final static String GROUP_NAME = "OperConsumerG1";

    public static <K,V> KafkaConsumer<K, V> createConsumer(String groupName) {
        Properties props = new Properties();
        props.put("bootstrap.servers", "localhost:9092");
        props.put("group.id", groupName);
        props.put("key.deserializer", "org.apache.kafka.common.serialization.StringDeserializer");
        props.put("value.deserializer", "io.confluent.kafka.serializers.KafkaAvroDeserializer");
        props.put("schema.registry.url", "http://localhost:8081");
        props.put("specific.avro.reader", "true");
        KafkaConsumer<K, V> consumer = new KafkaConsumer<>(props);
        return consumer;
    }

    public static void consumeSupplierV1() throws Exception {
        KafkaConsumer<String, SupplierV1> consumer = createConsumer(GROUP_NAME);
        consumer.subscribe(Arrays.asList(SchemaRegister.getCurrentTopic()));
        try {
            while (true) {
                ConsumerRecords<String, SupplierV1> records = consumer.poll(Duration.ofMillis(500));
                for (ConsumerRecord<String, SupplierV1> record : records) {
                    System.out.println("Id=" + record.value().getId()
                            + " Name=" + record.value().getName()
                            + " Date=" + record.value().getDate());
                }
            }
        }
        catch (Exception ex) {
            throw ex;
        }
        finally {
            consumer.close();
        }
    }

    public static void consumeOperation() throws Exception {
        KafkaConsumer<String, Operation> consumer = createConsumer(GROUP_NAME);
        consumer.subscribe(Arrays.asList(SchemaRegister.getCurrentTopic()));
        try {
            while (true) {
                ConsumerRecords<String, Operation> records = consumer.poll(Duration.ofMillis(500));
                for (ConsumerRecord<String, Operation> record : records) {
                    System.out.println("Id=" + record.value().getOperationId());
                    OperationModel opm = record.value().getOperationModel();
                    System.out.println("  Info = " + opm.getInfo().toString());
                }
            }
        }
        catch (Exception ex) {
            throw ex;
        }
        finally {
            consumer.close();
        }
    }


    /**
     * Main entry
     */
    public static void main(String[] args) {
        try {
            System.out.println("Starting up consumer ...");
            System.out.println();
            consumeOperation();
            // consumeSupplierV1();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

