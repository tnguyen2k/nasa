package poc;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.LongSerializer;
// import io.confluent.kafka.serializers.KafkaAvroSerializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.stream.IntStream;


/**
 * Class SupplierProducer
 */
public class SupplierProducer {
    public final static String TOPIC = "supplier";
    private static boolean IS_HAVING_SCHEMA = false;

    private static Producer<Long, Supplier> createProducer() {
        Properties props = new Properties();
        // Configure Supplier producer
        props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(ProducerConfig.CLIENT_ID_CONFIG, "SupplierProducer");
        props.put("key.serializer", "org.apache.kafka.common.serialization.LongSerializer");
        // props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, SupplierSerializer.class.getName());
        props.put("value.serializer", SupplierSerializer.class.getName());

        if (IS_HAVING_SCHEMA) {
            // Schema Registry location.  KafkaAvroSerializerConfig.SCHEMA_REGISTRY_URL_CONFIG can be used
            props.put("schema.registry.url", "http://localhost:8081");
        }

        return new KafkaProducer<>(props);
    }


    /**
     * Main entry
     */
    public static void main(String... args) {
        Producer<Long, Supplier> producer = createProducer();

        /*
        Supplier supplier = Supplier.newBuilder().setId(1)
                .setName("Supplier Name")
                .setDate("Oct 20202")
                .build();
        */

        // Create 5 messages for supplier
        List<Supplier> suppliers = new ArrayList<>();
        Supplier supplier = new Supplier(1, "Supplier Name1", "Oct 2001");
        suppliers.add(supplier);
        supplier = new Supplier(1, "Supplier Name2", "Oct 2002");
        suppliers.add(supplier);
        supplier = new Supplier(1, "Supplier Name3", "Oct 2003");
        suppliers.add(supplier);
        supplier = new Supplier(1, "Supplier Name4", "Oct 2004");
        suppliers.add(supplier);
        supplier = new Supplier(1, "Supplier Name5", "Oct 2005");
        suppliers.add(supplier);

        /*
        IntStream.range(1, 100).forEach(index->{
          producer.send(new ProducerRecord<>(TOPIC, 1L * index, bob));
        });
        */

        // Send 5 messages to supplier topic
        ProducerRecord<Long, Supplier> record = null;
        try {
            for (Supplier sup : suppliers) {
                record = new ProducerRecord<>(TOPIC, 1L, sup);
                producer.send(record);
                System.out.println("Successfull send data for " + sup.getName());
            }

            System.out.println();
        }
        catch(Exception e) {
            System.out.println("Error: " + e.getMessage());
            e.printStackTrace();
        }
        finally {
            producer.flush();
            producer.close();
        }
    }
}

