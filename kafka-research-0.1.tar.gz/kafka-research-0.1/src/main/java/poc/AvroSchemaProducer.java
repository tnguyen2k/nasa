package poc;

import java.util.Properties;
import java.util.UUID;
import org.apache.kafka.clients.producer.*;
import gov.nasa.arc.freddie.EventType;
import gov.nasa.arc.freddie.Operation;
import gov.nasa.arc.freddie.OperationModel;
import gov.nasa.arc.freddie.State;


/**
 * Class AvroSchemaProducer
 */
public class AvroSchemaProducer {
    public static <K,V> Producer<K,V> createProducer() {
        Properties props = new Properties();
        // props.put("bootstrap.servers", "localhost:9092,localhost:9093");
        props.put("bootstrap.servers", "localhost:9092");
        props.put("key.serializer", "org.apache.kafka.common.serialization.StringSerializer");
        props.put("value.serializer", "io.confluent.kafka.serializers.KafkaAvroSerializer");
        props.put("schema.registry.url", "http://localhost:8081");
        Producer<K, V> producer = new KafkaProducer<>(props);
        return producer;
    }

    public static void produceSupplierV1() throws Exception {
        Producer<String, SupplierV1> producer = createProducer();
        SupplierV1 cr = new SupplierV1(1, "SupplierV1.Name.2", "Jan/2020");
        try {
            producer.send(new ProducerRecord<String, SupplierV1>(SchemaRegister.getCurrentTopic(), cr.getId() + "", cr)).get();
            System.out.println("Complete");
        }
        catch (Exception ex) {
            ex.printStackTrace(System.out);
            throw ex;
        }
        finally {
            producer.close();
        }
    }

    public static void produceOperation() throws Exception {
        int totalMsgNum = 10;
        Producer<String, Operation> producer = createProducer();
        Operation op;
        try {
            OperationModel opModel = new OperationModel();
            opModel.setInfo("test-info");
            for (int i = 0; i < 10; ++i) {
                op = new Operation();
                op.setOperationId(generateUUID());
                op.setOperationModel(opModel);
                if (i % 2 == 0) {
                    op.setEventType(EventType.SUBMISSION);
                    op.setState(State.ACTIVATED);
                }
                else if (i % 3 == 0) {
                    op.setEventType(EventType.MODIFICATION);
                    op.setState(State.CONTINGENT);
                }
                else {
                    op.setEventType(EventType.ACCEPTED);
                    op.setState(State.ACCEPTED);
                }
                String strUUID = op.getOperationId().toString();
                System.out.println("- Generating UUID = " + strUUID);
                producer.send(new ProducerRecord<String, Operation>(SchemaRegister.getCurrentTopic(), "0", op));
            }

            System.out.println("Done with producer for Operation");
        }
        catch (Exception ex) {
            ex.printStackTrace(System.out);
            throw ex;
        }
        finally {
            producer.close();
        }
    }

    public static String generateUUID() {
        UUID uuid = UUID.randomUUID();
        return uuid.toString();
    }


    /**
     * Main entry
     */
    public static void main(String[] args) throws Exception {
        try {
            produceOperation();
            // produceSupplierV1();
        }
        catch (Exception ex) {
            System.out.println("Exception msg = " + ex.getMessage());
        }
    }
}

