package poc;

import java.util.Properties;
import kafka.admin.AdminUtils;
import kafka.admin.RackAwareMode;
import kafka.utils.ZKStringSerializer$;
import kafka.utils.ZkUtils;
import org.I0Itec.zkclient.ZkClient;
import org.I0Itec.zkclient.ZkConnection;


/**
 * Class KafkaTopicCreator
 */
public class KafkaTopicCreator {
    /**
     * Main Entry
     */
    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("Usage: <topic-name> <partition-number> <replication-number>");
            return;
        }

        ZkClient zkClient = null;
        ZkUtils zkUtils = null;

        try {
            System.out.println();
            String topicName = args[0];
            int noOfPartition = Integer.parseInt(args[1]);
            int noOfReplication = Integer.parseInt(args[2]);
            System.out.println("Creating topic       = " + topicName);
            System.out.println("  Partition Number   = " + noOfPartition);
            System.out.println("  Replication Number = " + noOfReplication);
            System.out.println();

            String zookeeperHosts = "localhost:2181"; // If multiple zookeeper then -> String zookeeperHosts = "192.168.20.1:2181,192.168.20.2:2181";
            int sessionTimeOutInMs = 15 * 1000; // 15 secs
            int connectionTimeOutInMs = 10 * 1000; // 10 secs

            zkClient = new ZkClient(zookeeperHosts, sessionTimeOutInMs, connectionTimeOutInMs, ZKStringSerializer$.MODULE$);
            zkUtils = new ZkUtils(zkClient, new ZkConnection(zookeeperHosts), false);
            Properties topicConfiguration = new Properties();
            AdminUtils.createTopic(zkUtils, topicName, noOfPartition, noOfReplication, topicConfiguration, RackAwareMode.Enforced$.MODULE$);
            System.out.println("Successfully created topic");
        }
        catch (Exception ex) {
            System.out.println("Error: " + ex.getMessage());
            ex.printStackTrace();
        }
        finally {
            if (zkClient != null) {
                zkClient.close();
            }
            if (zkUtils != null) {
                zkUtils.close();
            }
        }
    }
}

