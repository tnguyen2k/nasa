package poc;

import java.io.IOException;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;


/**
 * Class SchemaRegister
 */
public class SchemaRegister {
    public final static String EMPLOYEE_TOPIC = "employee";
    public final static String OP_TOPIC       = "operation";
    private static String CURRENT_TOPIC       = OP_TOPIC;

    private final static MediaType SCHEMA_CONTENT = MediaType.parse("application/vnd.schemaregistry.v1+json");

    /*
    private final static String EMPLOYEE_SCHEMA = "{\n" +
            "  \"schema\": \"" +
            "  {" +
            "    \\\"namespace\\\": \\\"poc\\\"," +
            "    \\\"type\\\": \\\"record\\\"," +
            "    \\\"name\\\": \\\"Supplier\\\"," +
            "    \\\"fields\\\": [" +
            "        {\\\"name\\\": \\\"id\\\", \\\"type\\\": \\\"int\\\", \\\"default\\\":-1}," +
            "        {\\\"name\\\": \\\"name\\\", \\\"type\\\": \\\"string\\\", \\\"default\\\":\\\"null\\\"}," +
            "        {\\\"name\\\": \\\"date\\\",  \\\"type\\\": \\\"string\\\", \\\"default\\\":\\\"null\\\"}" +
            "    ]" +
            "  }\"" +
            "}";

    private final static String OPERATION_SCHEMA = "{\n" +
      "  \"schema\": \"" +
      "  {" +
      "    \\\"type\\\":\\\"record\\\"," +
      "    \\\"name\\\":\\\"Operation\\\"," +
      "    \\\"namespace\\\":\\\"gov.nasa.arc.freddie\\\"," +
      "    \\\"fields\\\": [" +
      "     {\\\"name\\\":\\\"operation_id\\\"," +
      "      \\\"type\\\":\\\"string\\\"," +
      "      \\\"doc\\\":\\\"Not in ASTM schema. Must be assigned internally by event producer per business rules.\\\"," +
      "      \\\"default\\\":\\\"null\\\"," +
      "      \\\"logicalType\\\":\\\"UUID\\\"}," +
      "     {\\\"name\\\":\\\"event_type\\\"," +
      "      \\\"type\\\": {\\\"type\\\":\\\"enum\\\"," +
      "                     \\\"name\\\":\\\"EventType\\\"," +
      "                     \\\"symbols\\\":[\\\"UNKNOWN\\\",\\\"SUBMISSION\\\",\\\"MODIFICATION\\\",\\\"ACCEPTED\\\",\\\"DSS_SUBMISSION\\\",\\\"CANCELLED\\\"]}," +
      "      \\\"doc\\\":\\\"These are just prelimary types for testing concepts. Will need to align these with sagas.\\\"," +
      "      \\\"default\\\":\\\"UNKNOWN\\\"}," +
      "     {\\\"name\\\":\\\"state\\\"," +
      "      \\\"type\\\":{\\\"type\\\":\\\"enum\\\"," +
      "                    \\\"name\\\":\\\"State\\\"," +
      "                    \\\"symbols\\\":[\\\"UNKNOWN\\\",\\\"ACCEPTED\\\",\\\"ACTIVATED\\\",\\\"CONTINGENT\\\",\\\"CLOSED\\\",\\\"NONCONFORMING\\\",\\\"CANCELLED\\\"]}," +
      "                    \\\"doc\\\":\\\"Not in ASTM schema.  Not a definitive list yet.  Needs discussion and validation.\\\",\\\"default\\\":\\\"UNKNOWN\\\"}," +
      "     {\\\"name\\\":\\\"operation_model\\\"," +
      "      \\\"type\\\":{\\\"type\\\":\\\"record\\\"," +
      "                   \\\"name\\\":\\\"OperationModel\\\"," +
      "                   \\\"fields\\\":[{\\\"name\\\":\\\"info\\\"," +
      "                                    \\\"type\\\":\\\"string\\\"," +
      "                                    \\\"default\\\":\\\"null\\\"}]}," +
      "     \\\"doc\\\":\\\"This is where the 'real' model will go. With trajectory, operation info, etc.\\\"}" +
      "    ]}" +
      "}";

    private static String CURRENT_SCHEMA       = OPERATION_SCHEMA;
    */

    private static String CURRENT_SCHEMA       = null;

    public static void setCurrentSchema(final String currentSchema) {
        if ((currentSchema == null) || currentSchema.isEmpty()) {
            return;
        }
        CURRENT_SCHEMA = currentSchema;
    }

    public static String getCurrentSchema() {
        return CURRENT_SCHEMA;
    }

    public static void setCurrentTopic(final String currentTopic) {
        if ((currentTopic == null) || currentTopic.isEmpty()) {
            return;
        }
        CURRENT_TOPIC = currentTopic;
    }

    public static String getCurrentTopic() {
        return CURRENT_TOPIC;
    }

    public static void printUsage() {
        System.out.println();
        System.out.println("Usage: <topic> <avsc file>");
        System.out.println();
    }

    public static String readTextFile(final String strFileName) throws IOException {
        String content = "";
        content = new String(Files.readAllBytes(Paths.get(strFileName)));
        return content;
    }

    /**
     * Main Entry
     */
    public static void main(String... args) throws Exception {
        boolean isDebug = false;

        if (args.length != 2) {
            printUsage();
            return;
        }

        String topicSchema = null;
        String currentTopic = args[0];


        String avscFileName = args[1];
        File avscFile = new File(avscFileName);
        if (!avscFile.exists()) {
            System.out.println();
            System.out.println("Error: File " + avscFileName + " cannot be read.");
            System.out.println();
            return;
        }

        topicSchema = readTextFile(avscFileName);
        topicSchema = topicSchema.replace("\"", "\\\"");
        topicSchema = "{ \"schema\": \"" + topicSchema.trim() + "\" }";

        if (isDebug) {
            System.out.println();
            System.out.println(topicSchema);
            System.out.println();
            // System.out.println(OPERATION_SCHEMA);
        }

        System.out.println("Topic = " + currentTopic);
        System.out.println();
        setCurrentTopic(currentTopic);
        System.out.println(topicSchema);
        System.out.println();

        if (!KafkaUtil.topicExists(currentTopic)) {
            System.out.println();
            System.out.println("Error -> Topic must be created first: " + currentTopic);
            System.out.println();
            return;
        }

        final OkHttpClient client = new OkHttpClient();

        // POST A NEW SCHEMA
        Request request = new Request.Builder()
                .post(RequestBody.create(SCHEMA_CONTENT, topicSchema))
                .url("http://localhost:8081/subjects/" + currentTopic + "/versions")
                .build();

        String output = client.newCall(request).execute().body().string();
        System.out.println(output);

        // LIST ALL SCHEMAS
        request = new Request.Builder()
                .url("http://localhost:8081/subjects")
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);


        // SHOW ALL VERSIONS OF the topic
        request = new Request.Builder()
                .url("http://localhost:8081/subjects/" + currentTopic + "/versions/")
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);

        // SHOW VERSION 2 OF the topic
        request = new Request.Builder()
                .url("http://localhost:8081/subjects/" + currentTopic + "/versions/2")
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);

        // SHOW THE LATEST VERSION OF the topic
        request = new Request.Builder()
                .url("http://localhost:8081/subjects/" + currentTopic + "/versions/latest")
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);


        // CHECK IF SCHEMA IS REGISTERED
        request = new Request.Builder()
                .post(RequestBody.create(SCHEMA_CONTENT, topicSchema))
                .url("http://localhost:8081/subjects/" + currentTopic)
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);

        /*
        // TEST COMPATIBILITY
        request = new Request.Builder()
                .post(RequestBody.create(SCHEMA_CONTENT, topicSchema))
                .url("http://localhost:8081/compatibility/subjects/" + currentTopic + "/versions/latest")
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);

        // TOP LEVEL CONFIG
        request = new Request.Builder()
                .url("http://localhost:8081/config")
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);


        // SET TOP LEVEL CONFIG
        // VALUES are none, backward, forward and full
        request = new Request.Builder()
                .put(RequestBody.create(SCHEMA_CONTENT, "{\"compatibility\": \"none\"}"))
                .url("http://localhost:8081/config")
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);

        // SET CONFIG FOR a specified topic
        // VALUES are none, backward, forward and full
        request = new Request.Builder()
                .put(RequestBody.create(SCHEMA_CONTENT, "{\"compatibility\": \"backward\"}"))
                .url("http://localhost:8081/config/" + currentTopic)
                .build();

        output = client.newCall(request).execute().body().string();
        System.out.println(output);
        */
    }
}

