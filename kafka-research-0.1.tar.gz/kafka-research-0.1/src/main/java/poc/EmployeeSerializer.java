package poc;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.avro.io.BinaryEncoder;
import org.apache.avro.io.DatumWriter;
import org.apache.avro.io.EncoderFactory;

import com.fasterxml.jackson.databind.ObjectMapper;


/**
 * Class EmployeeSerializer
 */
public class EmployeeSerializer implements org.apache.kafka.common.serialization.Serializer<Employee> {
    protected static final byte MAGIC_BYTE = 0x0;
    protected static final int idSize = 4;
    private static int DEFAULT_CACHE_CAPACITY = 1000;
    private final EncoderFactory encoderFactory = EncoderFactory.get();

    @Override
    public void configure(Map map, boolean b) {
    }

    @Override
    public byte[] serialize(String s, Employee o) {
        byte[] retVal = null;
        boolean isByte = false;
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            // ByteArrayOutputStream baos = new ByteArrayOutputStream();
            // baos.write(MAGIC_BYTE);
            // baos.write(ByteBuffer.allocate(idSize).putInt(id).array());
            // DatumWriter<Object> writer;
            // writer.write(value, encoder);
            // encoder.flush();

            if (isByte) {
                ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ObjectOutputStream oos = new ObjectOutputStream(baos);
                oos.writeObject(o);
                oos.close();
                retVal = baos.toByteArray();
            }
            else {
                String strVal = objectMapper.writeValueAsString(o);
                System.out.println("----");
                System.out.println(strVal);
                System.out.println("----");
                retVal = objectMapper.writeValueAsString(o).getBytes();
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return retVal;
    }

    /*
    public byte[] serialize(String s, Employee o) {
       try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(o);
            oos.close();
            byte[] b = baos.toByteArray();
            return b;
        }
        catch (IOException e) {
            return new byte[0];
        }
    }
    */

    @Override
    public void close() {
    }
}

