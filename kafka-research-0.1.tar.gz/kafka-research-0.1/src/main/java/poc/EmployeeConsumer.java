package poc;

import org.apache.kafka.clients.consumer.*;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.common.serialization.LongDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Collections;
import java.util.Properties;


/**
 * Class EmployeeConsumer
 */
public class EmployeeConsumer {
    private static Consumer<Long, Employee> createConsumer() {
        final Properties props = new Properties();
         props.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
         props.put(ConsumerConfig.GROUP_ID_CONFIG, "EmployeeConsumerGroupId");
         props.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, LongDeserializer.class.getName());
         // props.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, EmployeeDeserializer.class.getName());
         props.put("value.deserializer", EmployeeDeserializer.class.getName());

         // Create the consumer using props.
         final Consumer<Long, Employee> consumer = new KafkaConsumer<>(props);

         // Subscribe to the topic.
         consumer.subscribe(Collections.singletonList(EmployeeProducer.TOPIC));
         return consumer;
    }

    static void runConsumer() throws InterruptedException {
        final Consumer<Long, Employee> consumer = createConsumer();
        final int giveUp = 60;
        int noRecordsCount = 0;

        System.out.println("Running consumer ...");
        while (true) {
            System.out.println("Polling data ...");
            final ConsumerRecords<Long, Employee> consumerRecords = consumer.poll(Duration.ofMillis(500));
            if (consumerRecords.count() == 0) {
                noRecordsCount++;
                if (noRecordsCount > giveUp)
                    break;
                else
                    continue;
            }

            /*
            consumerRecords.forEach(record -> {
                System.out.printf("Consumer Record:(%d, %s, %d, %d)\n",
                        record.key(), record.value(),
                        record.partition(), record.offset());
            });
            */

            for (ConsumerRecord<Long, Employee> record : consumerRecords) {
                System.out.printf("Consumer Record: (%d, %d, %d)\n", record.key(), record.partition(), record.offset());
                // System.out.println("Message received " + message.value().toString());
                Employee value = record.value();
                // System.out.println("First name = " + value.getFirstName());
            }


            consumer.commitAsync();
        }
        consumer.close();
        System.out.println("DONE");
    }


    /**
     * Main entry
     */
    public static void main(String... args) {
        try {
            runConsumer();
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}

