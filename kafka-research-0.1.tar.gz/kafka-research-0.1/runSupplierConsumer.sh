#!/bin/sh

CLASS_PATH="./target/kafka-poc-0.1.jar"

for entry in "./libs"/*.jar
do
  CLASS_PATH=$CLASS_PATH:"$entry"
done

# echo $CLASS_PATH

java -cp $CLASS_PATH poc.SupplierConsumer
